package com.phone.mycompiler

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient() // OkHttp client instance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputCode = findViewById<EditText>(R.id.inputCode)
        val runButton = findViewById<Button>(R.id.runButton)
        val outputResult = findViewById<TextView>(R.id.outputResult)

        runButton.setOnClickListener {
            val userInput = inputCode.text.toString()
            if (userInput.isNotEmpty()) {
                executeKotlinCode(userInput) { result ->
                    runOnUiThread { outputResult.text = result } // Update UI on the main thread
                }
            } else {
                outputResult.text = "Please enter some code to execute."
            }
        }
    }

    private fun executeKotlinCode(code: String, callback: (String) -> Unit) {
        val url = "https://api.jdoodle.com/v1/execute" // Replace with a real API endpoint

        val jsonPayload = """
            {
                "script": "$code",
                "language": "kotlin",
                "versionIndex": "0",
                "clientId": "e8e9602253d1999f9ecc102d0f734686",
                "clientSecret": "491020f40802112992921c0660a2875f510c03959296b6044eee3b6342152cf4"
            }
        """.trimIndent()

        val mediaType = "application/json".toMediaType() // Correct way to define MediaType in OkHttp 4.x
        val requestBody = jsonPayload.toRequestBody(mediaType) // Correct way to create RequestBody

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Request failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string() ?: "No response"
                callback(responseBody)
            }
        })
    }
}
